<?php
class ControllerExtensionModuleBlogArticle extends Controller {
public function index(){
	echo "hello world";
}
}

?>
